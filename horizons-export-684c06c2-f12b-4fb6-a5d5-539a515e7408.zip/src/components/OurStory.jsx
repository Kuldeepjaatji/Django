import React from 'react';
import { motion } from 'framer-motion';
import { Coffee, BookOpen, Award } from 'lucide-react';

const OurStory = () => {
  const values = [
    {
      icon: Coffee,
      title: 'Artisanal Roasting',
      description: 'We source the finest single-origin beans and roast them in-house to unlock their unique flavors.',
    },
    {
      icon: BookOpen,
      title: 'A Rich History',
      description: 'Founded in 2010, Aroma was born from a passion for creating a haven for coffee lovers.',
    },
    {
      icon: Award,
      title: 'Commitment to Quality',
      description: 'From bean to cup, we are dedicated to excellence in every detail of your experience.',
    },
  ];

  return (
    <section id="story" className="py-24 px-6 bg-[#211710]">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading gradient-text mb-6">Our Story</h2>
          <p className="text-lg text-white/70 max-w-3xl mx-auto">
            A journey of passion, dedication, and the relentless pursuit of the perfect cup.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="perspective-1000"
          >
            <div className="card-3d glass-effect rounded-2xl overflow-hidden">
              <img 
                alt="Vintage photo of the cafe's founder roasting coffee beans"
                className="w-full h-full object-cover"
               src="https://images.unsplash.com/photo-1698126216581-e8005a69f0db" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h3 className="text-3xl md:text-4xl font-heading text-white mb-4">
              More Than Just a Cafe
            </h3>
            <p className="text-white/70 leading-relaxed">
              Aroma was founded on the simple belief that coffee can be an experience. We've created a sanctuary where connoisseurs and newcomers alike can explore a world of flavor, guided by our expert baristas. Our commitment to quality is unwavering, and our passion is infectious.
            </p>
            
            <div className="space-y-4 pt-4">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.15 }}
                  viewport={{ once: true }}
                  className="flex items-start space-x-4"
                >
                  <div className="p-3 bg-gradient-to-br from-yellow-600/20 to-amber-700/20 rounded-full">
                    <value.icon className="text-yellow-400" size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl text-white mb-1">{value.title}</h4>
                    <p className="text-sm text-white/60">{value.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default OurStory;