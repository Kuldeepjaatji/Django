import React from 'react';
import { motion } from 'framer-motion';

const Gallery = () => {
  const images = [
    { src: 'A close-up shot of a perfectly poured latte with intricate art', alt: 'Latte art' },
    { src: 'The luxurious and warm interior of the Aroma cafe', alt: 'Cafe interior' },
    { src: 'A display of freshly baked, golden-brown pastries', alt: 'Fresh pastries' },
    { src: 'A smiling barista handing a cup of coffee to a customer', alt: 'Friendly barista' },
    { src: 'An overhead shot of a brunch table with various dishes', alt: 'Brunch spread' },
    { src: 'A cozy corner of the cafe with comfortable armchairs and books', alt: 'Cozy reading corner' },
  ];

  return (
    <section id="gallery" className="py-24 px-6 bg-[#211710]">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading gradient-text mb-6">Moments at Aroma</h2>
          <p className="text-lg text-white/70 max-w-3xl mx-auto">
            A glimpse into the atmosphere and artistry that define our cafe.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="perspective-1000 group"
            >
              <div className="card-3d rounded-lg overflow-hidden">
                <img 
                  alt={image.alt}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                 src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;