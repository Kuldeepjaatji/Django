import React from 'react';
import { motion } from 'framer-motion';
import { Coffee } from 'lucide-react';

const Background3D = () => {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    size: Math.random() * 8 + 4,
    x: Math.random() * 100,
    y: Math.random() * 100,
    duration: Math.random() * 30 + 20,
    delay: Math.random() * 10,
  }));

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-[#1a120b]">
      <div className="absolute inset-0 bg-gradient-to-br from-black/30 via-transparent to-black/30" />
      
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
          }}
          animate={{
            y: ['0vh', '100vh'],
            x: [0, Math.random() * 100 - 50],
            opacity: [0, 0.5, 0],
          }}
          transition={{
            duration: particle.duration,
            delay: particle.delay,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          {particle.id % 4 === 0 ? (
            <Coffee size={particle.size * 2} className="text-yellow-600/30" />
          ) : (
            <div
              className="rounded-full"
              style={{
                width: particle.size,
                height: particle.size,
                background: 'radial-gradient(circle, rgba(212,175,55,0.4) 0%, rgba(212,175,55,0) 70%)',
              }}
            />
          )}
        </motion.div>
      ))}

      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            radial-gradient(circle at 25% 25%, #d4af37 2px, transparent 0),
            radial-gradient(circle at 75% 75%, #d4af37 2px, transparent 0)
          `,
          backgroundSize: '100px 100px'
        }}
      />
    </div>
  );
};

export default Background3D;