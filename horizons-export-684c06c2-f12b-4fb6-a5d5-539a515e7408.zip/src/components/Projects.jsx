
import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Projects = () => {
  const projects = [
    {
      id: 1,
      title: 'E-Commerce Platform',
      description: 'A modern e-commerce solution with React, Node.js, and Stripe integration. Features include user authentication, product management, and secure payments.',
      image: 'Modern e-commerce website with shopping cart and product gallery',
      technologies: ['React', 'Node.js', 'MongoDB', 'Stripe'],
      category: 'Full-Stack',
    },
    {
      id: 2,
      title: 'Task Management App',
      description: 'Collaborative project management tool with real-time updates, drag-and-drop functionality, and team collaboration features.',
      image: 'Clean task management interface with kanban boards',
      technologies: ['Vue.js', 'Firebase', 'Vuetify'],
      category: 'Frontend',
    },
    {
      id: 3,
      title: 'Weather Dashboard',
      description: 'Beautiful weather application with location-based forecasts, interactive maps, and detailed weather analytics.',
      image: 'Modern weather dashboard with charts and maps',
      technologies: ['React', 'D3.js', 'Weather API'],
      category: 'Frontend',
    },
    {
      id: 4,
      title: 'Social Media Platform',
      description: 'Full-featured social networking platform with real-time messaging, post sharing, and user profiles.',
      image: 'Social media feed with posts and user interactions',
      technologies: ['Next.js', 'PostgreSQL', 'Socket.io'],
      category: 'Full-Stack',
    },
    {
      id: 5,
      title: 'Portfolio Website',
      description: 'Responsive portfolio website with 3D animations, smooth scrolling, and modern design principles.',
      image: 'Creative portfolio website with 3D elements',
      technologies: ['React', 'Three.js', 'Framer Motion'],
      category: 'Frontend',
    },
    {
      id: 6,
      title: 'Learning Management System',
      description: 'Educational platform with course management, video streaming, progress tracking, and interactive quizzes.',
      image: 'Educational platform with course videos and progress tracking',
      technologies: ['React', 'Express', 'MySQL', 'AWS'],
      category: 'Full-Stack',
    },
  ];

  const handleProjectAction = (action, projectTitle) => {
    toast({
      title: `🚧 ${action} for "${projectTitle}" isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀`,
    });
  };

  return (
    <section id="projects" className="py-20 px-6">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">Featured Projects</h2>
          <p className="text-lg text-white/70 max-w-3xl mx-auto">
            Explore my latest work showcasing modern web development techniques and creative solutions.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="perspective-1000"
            >
              <div className="card-3d glass-effect rounded-2xl overflow-hidden group hover:shadow-2xl transition-all duration-500">
                {/* Project Image */}
                <div className="relative overflow-hidden">
                  <img  
                    alt={project.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                   src="https://images.unsplash.com/photo-1572177812156-58036aae439c" />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-4 left-4 right-4 flex justify-between">
                      <Button
                        size="sm"
                        onClick={() => handleProjectAction('Live Demo', project.title)}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Eye size={16} className="mr-1" />
                        Demo
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleProjectAction('GitHub Repository', project.title)}
                        className="border-white/30 text-white hover:bg-white/10"
                      >
                        <Github size={16} className="mr-1" />
                        Code
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Project Info */}
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xl font-bold text-white">{project.title}</h3>
                    <span className="text-xs px-2 py-1 bg-blue-600/20 text-blue-400 rounded-full">
                      {project.category}
                    </span>
                  </div>
                  
                  <p className="text-white/70 text-sm mb-4 leading-relaxed">
                    {project.description}
                  </p>
                  
                  {/* Technologies */}
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="text-xs px-2 py-1 bg-white/10 text-white/80 rounded-md"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* View More Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button
            onClick={() => handleProjectAction('View All Projects', 'Portfolio')}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-full pulse-glow"
          >
            <ExternalLink size={20} className="mr-2" />
            View All Projects
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;
