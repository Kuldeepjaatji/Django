import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Facebook, Twitter } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: Instagram, name: 'Instagram' },
    { icon: Facebook, name: 'Facebook' },
    { icon: Twitter, name: 'Twitter' },
  ];

  const handleSocialClick = (name) => {
    toast({
      title: `🚧 ${name} link isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀`,
    });
  };

  return (
    <footer className="relative py-12 px-6 glass-effect border-t border-white/10">
      <div className="container mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <span className="text-4xl font-heading gradient-text mb-4 block">Aroma</span>
          <p className="text-white/70 max-w-md mx-auto mb-8">
            Where every cup is a masterpiece and every moment is cherished.
          </p>
          <div className="flex justify-center space-x-6 mb-8">
            {socialLinks.map(({ icon: Icon, name }) => (
              <motion.button
                key={name}
                onClick={() => handleSocialClick(name)}
                whileHover={{ scale: 1.2, y: -5 }}
                whileTap={{ scale: 0.9 }}
                className="p-3 glass-effect rounded-full hover:bg-white/10 transition-all duration-300"
              >
                <Icon size={20} className="text-white/70 hover:text-white" />
              </motion.button>
            ))}
          </div>
          <p className="text-white/60 text-sm">
            © {currentYear} Aroma Cafe & Roastery. All Rights Reserved.
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;