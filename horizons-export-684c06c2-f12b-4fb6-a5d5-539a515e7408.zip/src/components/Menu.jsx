import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Menu = () => {
  const [activeTab, setActiveTab] = useState('Coffee');

  const menuData = {
    Coffee: [
      { name: 'Espresso', description: 'A concentrated coffee beverage brewed by forcing hot water under pressure through finely-ground coffee beans.', price: '$3.50' },
      { name: 'Americano', description: 'Espresso shots topped with hot water to create a light layer of crema.', price: '$4.00' },
      { name: 'Caramel Macchiato', description: 'Freshly steamed milk with vanilla-flavored syrup, marked with espresso and topped with a caramel drizzle.', price: '$5.50' },
      { name: 'Golden Latte', description: 'A warm, comforting blend of turmeric, ginger, cinnamon, and steamed milk.', price: '$6.00' },
    ],
    Pastries: [
      { name: 'Almond Croissant', description: 'Flaky croissant filled with a sweet almond paste and topped with toasted almonds.', price: '$4.50' },
      { name: 'Chocolate Eclair', description: 'A delicate choux pastry filled with rich chocolate cream and topped with a glossy chocolate glaze.', price: '$5.00' },
      { name: 'Basque Cheesecake', description: 'A crustless cheesecake with a rich, creamy center and a beautifully caramelized top.', price: '$7.00' },
      { name: 'Pistachio Financier', description: 'A small French almond cake, flavored with beurre noisette and pistachio.', price: '$4.00' },
    ],
    Brunch: [
      { name: 'Avocado Toast', description: 'Sourdough toast topped with fresh avocado, chili flakes, and a poached egg.', price: '$14.00' },
      { name: 'Smoked Salmon Benedict', description: 'Toasted English muffin, smoked salmon, poached eggs, and hollandaise sauce.', price: '$18.00' },
      { name: 'Truffle Mushroom Risotto', description: 'Creamy Arborio rice with wild mushrooms, parmesan, and a hint of truffle oil.', price: '$22.00' },
      { name: 'Steak & Eggs', description: 'Grilled sirloin steak served with two eggs any style and roasted potatoes.', price: '$25.00' },
    ],
  };

  const handleOrder = (itemName) => {
    toast({
      title: `🚧 Ordering "${itemName}" isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀`,
    });
  };

  return (
    <section id="menu" className="py-24 px-6">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading gradient-text mb-6">Our Menu</h2>
          <p className="text-lg text-white/70 max-w-3xl mx-auto">
            A curated selection of artisanal coffees, delectable pastries, and gourmet brunch, crafted with passion.
          </p>
        </motion.div>

        <div className="flex justify-center mb-12">
          <div className="glass-effect p-2 rounded-full flex space-x-2">
            {Object.keys(menuData).map((tab) => (
              <Button
                key={tab}
                onClick={() => setActiveTab(tab)}
                variant={activeTab === tab ? 'default' : 'ghost'}
                className={`rounded-full px-6 py-2 transition-all duration-300 ${
                  activeTab === tab
                    ? 'bg-gradient-to-r from-yellow-600 to-amber-700 text-gray-900 font-bold'
                    : 'text-white/70 hover:bg-white/10 hover:text-white'
                }`}
              >
                {tab}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {menuData[activeTab].map((item, index) => (
            <motion.div
              key={item.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="perspective-1000"
            >
              <div
                onClick={() => handleOrder(item.name)}
                className="card-3d glass-effect rounded-2xl p-6 group hover:bg-white/5 transition-all duration-300 cursor-pointer"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">{item.name}</h3>
                    <p className="text-white/60 text-sm leading-relaxed pr-4">{item.description}</p>
                  </div>
                  <span className="text-xl font-bold gradient-text whitespace-nowrap">{item.price}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Menu;