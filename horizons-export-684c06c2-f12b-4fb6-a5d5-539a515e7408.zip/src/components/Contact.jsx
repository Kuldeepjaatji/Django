import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    guests: '',
    date: '',
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 Reservation request isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const contactInfo = [
    { icon: Mail, value: 'reservations@aroma.com' },
    { icon: Phone, value: '+1 (555) 987-6543' },
    { icon: MapPin, value: '123 Luxury Lane, Gold Valley, CA' },
    { icon: Clock, value: 'Mon - Sun: 7 AM - 9 PM' },
  ];

  return (
    <section id="contact" className="py-24 px-6">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-heading gradient-text mb-6">Visit Us</h2>
          <p className="text-lg text-white/70 max-w-3xl mx-auto">
            We invite you to experience Aroma. For reservations or inquiries, please get in touch.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="lg:col-span-2 space-y-8"
          >
            <h3 className="text-3xl font-heading text-white">Contact Information</h3>
            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex items-center space-x-4"
                >
                  <div className="p-3 glass-effect rounded-full">
                    <info.icon size={20} className="text-yellow-400" />
                  </div>
                  <span className="text-white/80">{info.value}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="lg:col-span-3 perspective-1000"
          >
            <form onSubmit={handleSubmit} className="card-3d glass-effect p-8 rounded-2xl space-y-6">
              <h3 className="text-2xl font-heading text-white mb-4">Book a Table</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full px-4 py-3 bg-black/20 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-yellow-500 transition-colors" placeholder="Your Name" required />
                <input type="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full px-4 py-3 bg-black/20 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-yellow-500 transition-colors" placeholder="your@email.com" required />
                <input type="number" name="guests" value={formData.guests} onChange={handleInputChange} className="w-full px-4 py-3 bg-black/20 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-yellow-500 transition-colors" placeholder="Number of Guests" required />
                <input type="datetime-local" name="date" value={formData.date} onChange={handleInputChange} className="w-full px-4 py-3 bg-black/20 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:border-yellow-500 transition-colors" required />
              </div>
              <Button type="submit" size="lg" className="w-full bg-gradient-to-r from-yellow-600 to-amber-700 hover:from-yellow-700 hover:to-amber-800 text-gray-900 font-bold py-3 rounded-lg pulse-glow">
                Request Reservation
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;