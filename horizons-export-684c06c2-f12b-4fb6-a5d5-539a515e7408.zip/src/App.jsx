import React from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import OurStory from '@/components/OurStory';
import Menu from '@/components/Menu';
import Gallery from '@/components/Gallery';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import Background3D from '@/components/Background3D';

function App() {
  return (
    <>
      <Helmet>
        <title>Aroma - Luxury Cafe & Roastery</title>
        <meta name="description" content="Experience the art of coffee at Aroma. A luxury cafe offering artisanal brews, gourmet food, and an unforgettable ambiance." />
      </Helmet>
      
      <div className="relative min-h-screen overflow-hidden">
        <Background3D />
        <Header />
        <main>
          <Hero />
          <OurStory />
          <Menu />
          <Gallery />
          <Contact />
        </main>
        <Footer />
        <Toaster />
      </div>
    </>
  );
}

export default App;